"""Real HTTP checks against only the dedicated reviewer loopback API."""
import datetime
import json
import sys
from urllib.error import HTTPError
from urllib.request import ProxyHandler, build_opener

port, expected_ready = int(sys.argv[1]), int(sys.argv[2])
assert port == 18001 and expected_ready in (200, 503)
opener = build_opener(ProxyHandler({}))
print(datetime.datetime.now(datetime.timezone.utc).isoformat())
for path, expected, state in [
    ("live", 200, "alive"),
    ("ready", expected_ready, "ready" if expected_ready == 200 else "not_ready"),
]:
    try:
        response = opener.open(f"http://127.0.0.1:{port}/health/{path}", timeout=10)
    except HTTPError as error:
        response = error
    with response:
        status, body = response.code, json.load(response)
    assert status == expected and body.get("status") == state, f"{path}: unexpected health result"
    print(f"{path}: {status} / {state}")
