"""Complete the unchanged repository tests from the non-cloud, verified clone."""
import run_reproduction as r

r.run("41-git-object-integrity", ["git", "fsck", "--no-dangling"])
r.run("42-container-source-match", [r.PY, str(r.ROOT / "verify_container_sources.py")])
local = [r.PY, "-B", "tools/environment/local.py", "--env-file", r.ENVFILE, "run", "python"]
r.run("43-environment-all", [*local, "tools/checks/run.py", "environment"], 240)
r.run("44-four-real-db-tests", [*local, "-m", "pytest", "tests/environment", "-m", "database", "-v"], 180)
r.run("45-repeat-migration", [*local, "-m", "alembic", "upgrade", "head"])
r.run("46-current-migration", [*local, "-m", "alembic", "current"])
r.run("47-missing-config", [r.PY, "-c", "import os,subprocess,sys; e=os.environ.copy(); e.pop('DATABASE_URL',None); r=subprocess.run([sys.executable,'-B','tools/checks/run.py','environment'],env=e); print('Missing-config child exit:',r.returncode,'expected 2'); sys.exit(0 if r.returncode==2 else 1)"])
r.run("48-final-git-status", ["git", "status", "--porcelain"])
r.run("49-final-git-integrity", ["git", "fsck", "--no-dangling"])
r.docker("50-compose-final-status", [*r.COMPOSE, "ps", "-a"])
r.docker("51-stop-owned-project", [*r.COMPOSE, "stop"])
r.docker("52-stopped-project", [*r.COMPOSE, "ps", "-a"])
r.run("53-final-source-sha", ["git", "rev-parse", "HEAD"])
