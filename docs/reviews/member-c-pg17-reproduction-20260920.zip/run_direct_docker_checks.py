"""Continue runtime-only checks on the verified owned Compose containers.

Avoids re-reading the stalled Desktop Compose/Alembic files. This cannot claim
the separate host pytest/environment suite passed; those remain separately logged.
"""
import subprocess
import time
import run_reproduction as r

API = r.PROJECT + "-api-1"
DB = r.PROJECT + "-db-1"
MIGRATE = r.PROJECT + "-migrate-1"
identity = "{{.Id}} image={{.Image}} started={{.State.StartedAt}} restartCount={{.RestartCount}}"
docker_base = [r.DOCKER, "--context", r.CONTEXT]

for name in (API, DB, MIGRATE):
    owner = subprocess.check_output(docker_base + ["inspect", name, "--format", '{{index .Config.Labels "com.docker.compose.project"}}'], text=True, timeout=15).strip()
    assert owner == r.PROJECT
r.docker("direct-01-owned-resources", ["ps", "-a", "--filter", "label=com.docker.compose.project=" + r.PROJECT, "--format", "{{.ID}} {{.Names}} {{.Status}} {{.Ports}}"])
r.docker("direct-02-pg-version-schema", ["exec", DB, "psql", "-U", "returnops_dev", "-d", "returnops_f02", "-Atc", "select version(); select version_num from alembic_version; select tablename from pg_tables where schemaname='public' order by tablename;"])
r.docker("direct-03-pg-image-digest", ["image", "inspect", "postgres:17-bookworm@sha256:051f7b7b3abdd564d5d1bd1e8c4b9c1b6e77087d1dd22020ede611c096a272e0", "--format", "{{.Id}} {{json .RepoDigests}}"])
r.docker("direct-04-api-identity-before", ["inspect", API, "--format", identity])
r.docker("direct-05-api-process-before", ["top", API])
r.docker("direct-06-api-runtime", ["exec", API, "python", "-c", "import os,platform; print(platform.python_version()); print('uid='+str(os.getuid()))"])
r.docker("direct-07-repeat-migration1", ["start", "-a", MIGRATE])
r.docker("direct-08-repeat-migration2", ["start", "-a", MIGRATE])
r.docker("direct-09-repeat-revision", ["exec", DB, "psql", "-U", "returnops_dev", "-d", "returnops_f02", "-Atc", "select version_num from alembic_version; select tablename from pg_tables where schemaname='public' order by tablename;"])
r.run("direct-10-http-before", [r.PY, str(r.ROOT / "check_http.py"), str(r.APIPORT), "200"])
r.docker("direct-11-stop-owned-db", ["stop", DB])
try:
    r.run("direct-12-http-outage", [r.PY, str(r.ROOT / "check_http.py"), str(r.APIPORT), "503"])
    r.docker("direct-13-api-process-outage", ["top", API])
finally:
    r.docker("direct-14-start-owned-db", ["start", DB])
for _ in range(30):
    healthy = subprocess.check_output(docker_base + ["inspect", DB, "--format", "{{.State.Health.Status}}"], text=True, timeout=10).strip()
    if healthy == "healthy":
        break
    time.sleep(1)
else:
    raise RuntimeError("Owned PostgreSQL did not recover healthy")
r.run("direct-15-http-recovered", [r.PY, str(r.ROOT / "check_http.py"), str(r.APIPORT), "200"])
r.docker("direct-16-api-identity-after", ["inspect", API, "--format", identity])
r.docker("direct-17-api-process-after", ["top", API])
r.docker("direct-18-runtime-resource-status", ["ps", "-a", "--filter", "label=com.docker.compose.project=" + r.PROJECT, "--format", "{{.ID}} {{.Names}} {{.Status}} {{.Ports}}"])
r.docker("direct-19-api-logs", ["logs", "--timestamps", API])
r.docker("direct-20-db-logs", ["logs", "--timestamps", DB])
print("Direct runtime checks complete; host pytest is not implied.", flush=True)
