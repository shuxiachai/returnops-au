"""AI-assisted execution of the repository's exact-SHA F.02 reproduction packet.

Keeps logs outside the clean checkout. Manages only its unique local Compose
project, never deletes volumes, and records technical results, not acceptance.
"""
from __future__ import annotations
import datetime as dt
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = Path(os.environ.get("F02_REPRO_SOURCE", str(ROOT / "source")))
LOG_PREFIX = os.environ.get("F02_REPRO_LOG_PREFIX", "")
LOGS = ROOT / "logs"
LOGS.mkdir(exist_ok=True)
PY = str(SOURCE / ".venv/bin/python")
DOCKER = "/Applications/Docker.app/Contents/Resources/bin/docker"
NODE = "/Users/user/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
NPM = str(ROOT / "node-v24.19.0-darwin-arm64/lib/node_modules/npm/bin/npm-cli.js")
SHA = "3dd1ff637693a826990eee5712cfb239a3c3da7b"
BASE = "9eb7b0b46b1b28cfec300a59b03bba6a1d60c3bf"
PROJECT = "returnops-au-f02-c-20260920-1920"
CONTEXT = "desktop-linux"
ENDPOINT = "unix:///Users/user/.docker/run/docker.sock"
ENVFILE = ".env.f02-c-review"
DBPORT, APIPORT = 15433, 18001
ENV = os.environ.copy()
ENV["PATH"] = str(Path(NODE).parent) + os.pathsep + ENV["PATH"]
ENV["PYTHONDONTWRITEBYTECODE"] = "1"
ENV["PYTHONUNBUFFERED"] = "1"


def run(label: str, args: list[str], timeout: int = 240, expected: int = 0) -> str:
    path = LOGS / f"{LOG_PREFIX}{label}.log"
    if path.exists():
        raise RuntimeError(f"Will not overwrite existing log: {path.name}")
    print(f"START {label}", flush=True)
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    with path.open("x", encoding="utf-8") as log:
        log.write(f"Started UTC: {started}\nCommand: {json.dumps(args)}\n")
        log.flush()
        try:
            result = subprocess.run(args, cwd=SOURCE, env=ENV, text=True,
                                    stdout=log, stderr=subprocess.STDOUT,
                                    timeout=timeout, check=False)
        except subprocess.TimeoutExpired:
            log.write(f"\nTIMEOUT after {timeout} seconds\n")
            raise
        log.write(f"\nExit: {result.returncode}\nFinished UTC: {dt.datetime.now(dt.timezone.utc).isoformat()}\n")
    print(f"END {label} exit={result.returncode}", flush=True)
    if result.returncode != expected:
        raise RuntimeError(f"{label} exited {result.returncode}; expected {expected}; see {path}")
    return path.read_text(encoding="utf-8")


def docker(label: str, args: list[str], timeout: int = 240) -> str:
    for key in ("DOCKER_HOST", "DOCKER_CONTEXT"):
        if key in os.environ:
            raise RuntimeError(f"Unexpected environment override: {key}")
    check = subprocess.run([DOCKER, "--context", CONTEXT, "context", "inspect", CONTEXT,
                            "--format", "{{.Endpoints.docker.Host}}"],
                           capture_output=True, text=True, check=True, timeout=20)
    if check.stdout.strip() != ENDPOINT:
        raise RuntimeError("Verified local Docker endpoint changed")
    return run(label, [DOCKER, "--context", CONTEXT, *args], timeout)


COMPOSE = ["compose", "-f", "compose.yaml", "--env-file", ENVFILE, "-p", PROJECT]


def prepare() -> None:
    for key in ("POSTGRES_USER", "POSTGRES_PASSWORD", "POSTGRES_DB", "DB_PORT", "API_PORT", "DOCKER_HOST", "DOCKER_CONTEXT"):
        if key in os.environ:
            raise RuntimeError(f"Unexpected environment override: {key}")
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True).strip()
    status = subprocess.check_output(["git", "status", "--porcelain"], cwd=SOURCE, text=True)
    assert head == SHA and not status, "Exact source and clean worktree required"
    run("00-source", ["git", "log", "-1", "--format=fuller"])
    run("01-initial-git-status", ["git", "status", "--porcelain"])
    run("02-python-version", [PY, "--version"])
    run("03-locked-install", [PY, "-m", "pip", "install", "--require-hashes", "-r", "requirements-dev.lock"], 600)
    run("04-editable-install", [PY, "-m", "pip", "install", "--no-deps", "--no-build-isolation", "-e", "."])
    run("05-pip-check", [PY, "-m", "pip", "check"])
    run("06-healthcheck-proxy-regressions", [PY, "-B", "-m", "pytest", "tests/environment/test_compose_healthcheck.py", "-q"])
    run("07-node-version", [NODE, "--version"])
    run("08-npm-version", [NODE, NPM, "--version"])
    run("09-npm-ci", [NODE, NPM, "ci", "--prefix", "tools/model-checks", "--ignore-scripts", "--no-audit", "--no-fund"], 300)
    run("10-offline", [PY, "-B", "tools/checks/run.py", "offline", "--baseline-ref", BASE], 240)


def compose_start() -> None:
    docker("11-docker-version", ["version"])
    docker("12-compose-version", ["compose", "version"])
    os_result = docker("13-engine-os", ["info", "--format", "{{.OSType}}"])
    assert "\nlinux\n" in os_result
    projects = docker("14-initial-projects", ["compose", "ls", "--format", "json"])
    assert PROJECT not in projects
    volumes = docker("15-initial-volumes", ["volume", "ls", "--format", "{{.Name}}"])
    assert PROJECT not in volumes
    run("16-ports-free", [PY, "-c", "import socket; ports=[15433,18001]; sockets=[socket.socket() for _ in ports]; [s.bind(('127.0.0.1',p)) for s,p in zip(sockets,ports)]; print('Requested loopback ports available'); [s.close() for s in sockets]"])
    docker("17-compose-config", [*COMPOSE, "config", "--quiet"])
    docker("18-compose-build-start", [*COMPOSE, "up", "--build", "-d", "--wait", "--wait-timeout", "180"], 900)
    docker("19-compose-ps", [*COMPOSE, "ps", "-a"])


def runtime() -> None:
    local = [PY, "-B", "tools/environment/local.py", "--env-file", ENVFILE, "run", "python"]
    run("20-environment-all", [*local, "tools/checks/run.py", "environment"], 240)
    run("21-four-real-db-tests", [*local, "-m", "pytest", "tests/environment", "-m", "database", "-v"], 180)
    run("22-repeat-migration", [*local, "-m", "alembic", "upgrade", "head"])
    run("23-current-migration", [*local, "-m", "alembic", "current"])
    docker("24-pg-version-schema", [*COMPOSE, "exec", "-T", "db", "psql", "-U", "returnops_dev", "-d", "returnops_f02", "-Atc", "select version(); select version_num from alembic_version; select tablename from pg_tables where schemaname='public' order by tablename;"])
    docker("25-api-runtime", [*COMPOSE, "exec", "-T", "api", "python", "-c", "import os,platform; print(platform.python_version()); print('uid='+str(os.getuid()))"])
    docker("25a-pg-image-digest", ["image", "inspect", "postgres:17-bookworm@sha256:051f7b7b3abdd564d5d1bd1e8c4b9c1b6e77087d1dd22020ede611c096a272e0", "--format", "{{.Id}} {{json .RepoDigests}}"])
    docker("25b-api-identity-before", ["inspect", PROJECT + "-api-1", "--format", "{{.Id}} image={{.Image}} started={{.State.StartedAt}} restartCount={{.RestartCount}}"])
    docker("26-api-before", [*COMPOSE, "top", "api"])
    run("27-http-before", [PY, str(ROOT / "check_http.py"), str(APIPORT), "200"])
    docker("28-stop-owned-db", [*COMPOSE, "stop", "db"])
    try:
        run("29-http-outage", [PY, str(ROOT / "check_http.py"), str(APIPORT), "503"])
        docker("30-api-during-outage", [*COMPOSE, "top", "api"])
    finally:
        docker("31-start-owned-db", [*COMPOSE, "start", "db"])
    docker("32-recovery-wait", [*COMPOSE, "up", "-d", "--wait", "--wait-timeout", "90"], 120)
    run("33-http-recovered", [PY, str(ROOT / "check_http.py"), str(APIPORT), "200"])
    docker("34-api-after", [*COMPOSE, "top", "api"])
    docker("34a-api-identity-after", ["inspect", PROJECT + "-api-1", "--format", "{{.Id}} image={{.Image}} started={{.State.StartedAt}} restartCount={{.RestartCount}}"])
    docker("35-final-compose-ps", [*COMPOSE, "ps", "-a"])
    run("36-missing-config", [PY, "-c", "import os,subprocess,sys; e=os.environ.copy(); e.pop('DATABASE_URL',None); r=subprocess.run([sys.executable,'-B','tools/checks/run.py','environment'],env=e); print('Missing-config child exit:',r.returncode,'expected 2'); sys.exit(0 if r.returncode==2 else 1)"])
    run("37-final-git-status", ["git", "status", "--porcelain"])
    docker("38-owned-service-logs", [*COMPOSE, "logs", "--no-color", "--timestamps", "db", "migrate", "api"])
    docker("39-stop-owned-project", [*COMPOSE, "stop"])
    docker("40-stopped-project", [*COMPOSE, "ps", "-a"])


if __name__ == "__main__":
    {"prepare": prepare, "start": compose_start, "runtime": runtime}[sys.argv[1]]()
