"""Compare actual running-image source bytes with the fresh exact-SHA Git clone."""
import hashlib
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = Path("/private/tmp/returnops-c-publish-3bx5MD/repo")
sha = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True).strip()
assert sha == "3dd1ff637693a826990eee5712cfb239a3c3da7b"
actual = (ROOT / "logs/direct-21-container-source-hashes.log").read_text()
pairs = re.findall(r"^([0-9a-f]{64})  ([^\n]+)$", actual, re.MULTILINE)
assert len(pairs) == 9
for digest, name in pairs:
    assert hashlib.sha256((SOURCE / name).read_bytes()).hexdigest() == digest, name
    print(f"MATCH {digest}  {name}")
print(f"All 9 container source/runtime-lock files match clean Git source {sha}.")
