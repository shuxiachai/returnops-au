# C F.02 clean-Git prerequisite reproduction — 2026-09-18

Status: **clean Git checkout and all offline prerequisites passed; PostgreSQL 17 / Docker Compose reproduction has not been performed in this execution.** This is Codex-assisted execution on C's Mac, not Lucas Tao's personal signature, independent oral explanation or joint acceptance. No commit, push, merge, Jira change, business implementation or F.02 Done is asserted.

## Source and environment

- Authenticated real Git clone: `../f02-repro`, made into a previously absent directory via the normally authorized GitHub CLI. No ZIP-to-Git reconstruction and no browser/token extraction.
- Exact detached HEAD: `3dd1ff637693a826990eee5712cfb239a3c3da7b` (`[KAN-32] Fix historical citation verification coverage (C-F01)`).
- Exact offline comparison baseline: `9eb7b0b46b1b28cfec300a59b03bba6a1d60c3bf`.
- Initial and final `git status --porcelain=v1` output: empty. `git fsck --connectivity-only`, `git diff --exit-code` and `git diff --cached --exit-code`: exit 0.
- Machine: macOS 26.6.2 / build 25G83 / arm64; Git 2.50.1 (Apple Git-155).
- Execution window: 2026-09-18 23:29:38–23:33:53 Australia/Sydney (UTC+10).
- Fresh `.venv`: CPython 3.12.14, `include-system-site-packages = false`; initial pip 25.0.1. No global Python installation or package upgrade.
- Node 24.19.0; npm 11.17.0. The successful npm install and offline run used the existing bundled Node executable with fresh npm tool files as described below.
- Existing environment override names checked: `POSTGRES_USER`, `POSTGRES_PASSWORD`, `POSTGRES_DB`, `DB_PORT`, `API_PORT`, `DATABASE_URL`, `DOCKER_HOST`, `DOCKER_CONTEXT`; none present. Only variable names were checked, no values disclosed.
- Read the exact checkout's full `AGENTS.md`, docs/10, F.02 independent reproduction guide, A defect-closure note and check-runner guide before execution. Historical acceptance/publication text remains historical.

## Actual results

| Check | Result |
|---|---|
| `pip --isolated install --require-hashes -r requirements-dev.lock` | exit 0; exact committed hash lock installed into fresh venv |
| Editable install `--no-deps --no-build-isolation -e .` | exit 0; installed build dependencies reused |
| `pip check` | exit 0, no broken requirements |
| Actual Compose probe regression (no Docker/DB) | **2 passed**, exit 0 |
| `npm ci --prefix tools/model-checks --ignore-scripts --no-audit --no-fund` | **195 packages added**, exit 0; successful retry with freshly extracted official npm tool files |
| Contract artifacts | **58 tests passed** |
| Static document/model checks | **6/6 groups**; 33 Markdown files / 349 local targets |
| Actual Git-ref WBS comparison | All **89** ID/Owner/Reviewer/S/F tuples unchanged from exact `9eb7b0b…`; valid acyclic graph; **not skipped** |
| SVG source correspondence | **9** source/SVG pairs matched; no rendering or visual inspection claimed |
| A model references | 21 scenarios, 41 action IDs, 7 states |
| Composite references | 3 views, 57 port appearances, 29 registered connectors, 13 scenarios, five named boundary adjacencies |
| Model checker regressions | **12 tests passed** |
| Unified-runner regressions | **5 tests passed** |
| Mermaid grammar | **15 blocks parsed**, 0 failures |
| Full offline entry point | **5/5 steps**, exit 0 |
| Non-database environment subset | **28 passed, 4 database deselected, 2 warnings**, exit 0; not full environment testing |
| Missing `DATABASE_URL` negative check | Child exit **2**, before migration; wrapper exit 0; not a failed remote Actions run |
| Source preservation | Initial and final Git status empty; no tracked sources/tests/locks modified |

The full offline command was:

```sh
.venv/bin/python -B tools/checks/run.py offline \
  --baseline-ref 9eb7b0b46b1b28cfec300a59b03bba6a1d60c3bf
```

It ran with the bundled Node directory on only the child process PATH and `PYTHONDONTWRITEBYTECODE=1`. Pytest-only checks also used `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1` and `-p no:cacheprovider`, isolating unrelated pytest plugins/cache writes; no tests were changed or skipped other than the explicitly requested non-database subset's four database tests.

## Tool-startup retries and warnings

The old task-local Node distribution's `npm --version` had earlier succeeded, but two later `npm ci` attempts stalled before package installation. First attempt used the old Node; second used bundled Node with the same old npm files. They produced empty output logs and no observed network connections. A one-second sample showed npm synchronously reading its module files. Each owned npm process was stopped with SIGTERM (exit 143); no unrelated process was stopped. The reason for old-directory read latency was not established.

Instead of altering application code, locks, global caches or security settings, npm and LICENSE were freshly extracted to `../runtime-node/` from the existing official `node-v24.19.0-darwin-arm64.tar.gz`. Its rechecked SHA-256 was `8294b7aa9b03997481c06babf1e8b270c859358f27da57a11509afe537ac381d`, matching the previously verified official versioned checksum. The same npm command with bundled Node then added 195 packages in 1 second and exited 0. Old tool files were preserved. A diagnostic read-only tar traversal of old npm files was also stopped when no longer needed. These retries are not application test failures or successful Compose evidence.

Retained upstream warnings, not suppressed or repaired by changing dependency versions:

```text
npm warn deprecated whatwg-encoding@3.1.1: Use @exodus/bytes instead for a more spec-conformant and faster implementation
npm warn deprecated uuid@9.0.1: uuid@10 and below is no longer supported. For ESM codebases, update to uuid@latest. For CommonJS codebases, use uuid@11 (but be aware this version will likely be deprecated in 2028).
StarletteDeprecationWarning: Using `httpx` with `starlette.testclient` is deprecated; install `httpx2` instead.
DeprecationWarning: The anyio.abc.BlockingPortal alias is deprecated, use anyio.from_thread.BlockingPortal instead.
```

The install also displayed a pip update advertisement; it was not acted upon. Exact original warning formatting is retained in the corresponding raw logs.

## Evidence and remaining boundary

`SHA256SUMS.txt` contains hashes of the 13 selected source/version/install/check/status logs. The two interrupted npm logs are retained as empty diagnostic files; `npm-startup-sample.txt` is local diagnostic context and is not necessary for a published proof bundle. No env file, database, token, password or browser data is included. A pattern scan of `.log` files found no GitHub token, Bearer token or credential-bearing PostgreSQL URL; the missing-config error contains only the literal placeholder `postgresql+psycopg://.../returnops_f02`.

This run did **not** create an env file, start Docker or PostgreSQL, build an image, run a migration, create a volume, run the four real database tests, or perform actual container healthy/outage/recovery HTTP checks. Those still require the verified local Docker endpoint and a new isolated Compose project/PG17 volume, followed by the exact reproduction guide. Existing GitHub CI or native PG16 results cannot replace them. Joint F.01/F.02 acceptance, Lucas's own explanation/confirmation, required-check/failure-evidence conditions and course submission remain separate factual records.
