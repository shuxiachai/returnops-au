"""Additional C-native recovery evidence; does not edit upstream tools or use Docker."""
from datetime import datetime
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import tempfile
import time
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, build_opener
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
ROOT = HERE / "returnops-au-fix-10-kan-32-contract-review"
PY = HERE.parent / "returnops-au-fix-10-kan-32-contract-review/.venv-c-review/bin/python"
PG = Path("/Library/PostgreSQL/16/bin")
DB_PORT, API_PORT = 15434, 18002
for name in ("POSTGRES_USER", "POSTGRES_PASSWORD", "POSTGRES_DB", "DB_PORT", "API_PORT", "DATABASE_URL"):
    if name in os.environ:
        raise SystemExit(f"Existing override: {name}; stop")
for port in (DB_PORT, API_PORT):
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", port))
WORK = Path(tempfile.mkdtemp(prefix="f02-c-recovery-", dir=ROOT / "tmp"))
DATA = WORK / "data"
PASSWORD_FILE = WORK / "init-password.txt"
SECRET = secrets.token_hex(32)
ENV = {k: v for k, v in os.environ.items() if not k.upper().startswith("PG")}
ENV.update(PGPASSWORD=SECRET, PGCONNECT_TIMEOUT="3", PGPASSFILE=str(WORK / "unused.pgpass"),
           DATABASE_URL=f"postgresql+psycopg://returnops_c:{SECRET}@127.0.0.1:{DB_PORT}/returnops_f02_c_recovery",
           PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
           PYTEST_ADDOPTS="-p no:cacheprovider", NO_COLOR="1")
LOG = WORK / "recovery.log"
API_LOG = WORK / "api.log"
PG_LOG = WORK / "postgres.log"
api = None
api_output = None
events = []
opener = build_opener(ProxyHandler({}))

def record(text):
    line = f"{datetime.now(ZoneInfo('Australia/Sydney')).isoformat()} {text}"
    events.append(line)
    print(line, flush=True)

def run(args, expected=0):
    record("Command " + repr([str(a) for a in args]))
    result = subprocess.run([str(a) for a in args], cwd=ROOT, env=ENV,
                            capture_output=True, text=True, timeout=45)
    output = result.stdout + result.stderr
    if SECRET in output:
        raise RuntimeError("Credential detected; do not publish this run")
    events.append(output.rstrip())
    record(f"Exit {result.returncode}")
    if result.returncode != expected:
        raise RuntimeError("Native recovery command failed")

def start_db():
    run([PG / "pg_ctl", "-D", DATA, "-l", PG_LOG, "-w", "-t", "30", "start"])

def stop_db():
    status = subprocess.run([str(PG / "pg_ctl"), "-D", str(DATA), "status"], capture_output=True)
    if status.returncode == 0 or (DATA / "postmaster.pid").exists():
        run([PG / "pg_ctl", "-D", DATA, "-w", "-t", "30", "-m", "fast", "stop"])
    elif status.returncode not in (3, 4):
        raise RuntimeError("Cannot establish owned cluster status")

def response(path):
    try:
        result = opener.open(f"http://127.0.0.1:{API_PORT}/health/{path}", timeout=8)
    except HTTPError as error:
        result = error
    with result:
        body = result.read(4096)
        assert SECRET.encode() not in body
        return result.code, json.loads(body)

def health(stage, ready):
    live = response("live")
    actual = response("ready")
    assert live == (200, {"status": "alive"})
    assert actual == (ready, {"status": "ready" if ready == 200 else "not_ready"})
    record(f"{stage}: live={live[0]}, ready={actual[0]}")

try:
    record("Agent-assisted C-native run; PostgreSQL16.2, not PostgreSQL17/Compose acceptance")
    with os.fdopen(os.open(PASSWORD_FILE, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "w") as password_out:
        password_out.write(SECRET + "\n")
    run([PG / "initdb", "-D", DATA, "-U", "returnops_c", "--auth=scram-sha-256",
         "--pwfile", PASSWORD_FILE, "--encoding=UTF8", "--locale=C"])
    PASSWORD_FILE.unlink()
    with (DATA / "postgresql.conf").open("a") as configuration:
        configuration.write(f"\nlisten_addresses='127.0.0.1'\nport={DB_PORT}\nunix_socket_directories=''\n")
    start_db()
    run([PG / "createdb", "-h", "127.0.0.1", "-p", DB_PORT, "-U", "returnops_c", "-w",
         "--maintenance-db=postgres", "returnops_f02_c_recovery"])
    run([PY, "-B", "tools/checks/run.py", "environment"])
    run([PG / "psql", "-h", "127.0.0.1", "-p", DB_PORT, "-U", "returnops_c", "-w",
         "-d", "returnops_f02_c_recovery", "-Atc", "select version_num from alembic_version"])
    api_output = API_LOG.open("w")
    api = subprocess.Popen([str(PY), "-B", "-m", "uvicorn", "returnops_api.main:create_app", "--factory",
                            "--host", "127.0.0.1", "--port", str(API_PORT)], cwd=ROOT, env=ENV,
                           stdout=api_output, stderr=subprocess.STDOUT)
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        if api.poll() is not None:
            raise RuntimeError("Owned API terminated")
        try:
            if response("ready") == (200, {"status": "ready"}):
                break
        except (URLError, TimeoutError, OSError):
            pass
        time.sleep(0.2)
    else:
        raise RuntimeError("Owned API startup timed out")
    health("Initial", 200)
    stop_db()
    try:
        health("Owned database stopped", 503)
    finally:
        start_db()
    health("Same owned database restarted", 200)
    record("Recovery succeeded without replacing the API process or database directory")
finally:
    if api is not None and api.poll() is None:
        api.terminate()
        try:
            api.wait(timeout=10)
        except subprocess.TimeoutExpired:
            api.kill()
            api.wait(timeout=10)
    if api_output is not None:
        api_output.close()
    if DATA.exists():
        stop_db()
    PASSWORD_FILE.unlink(missing_ok=True)
    record("Owned API and cluster stopped; synthetic cluster data retained locally")
    content = "\n".join(events) + "\n"
    assert SECRET not in content
    LOG.write_text(content, encoding="utf-8")
    for file in (LOG, API_LOG, PG_LOG):
        if file.exists():
            assert SECRET not in file.read_text(encoding="utf-8", errors="replace")
    print(f"Evidence: {WORK}")
