"""Package only sanitised reviewer logs/scripts, never DB data or env/password files."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "returnops-au-fix-10-kan-32-contract-review"
FILES = {"logs/" + p.name: p for p in sorted((HERE / "logs").glob("*.log"))}
for label, folder, names in [
    ("native-upstream", "f02-native-t6vgyl3y", ("commands.log", "api.log", "postgres.log")),
    ("native-recovery", "f02-c-recovery-4t8x4f9_", ("recovery.log", "api.log", "postgres.log")),
]:
    for name in names:
        FILES[f"{label}/{name}"] = SOURCE / "tmp" / folder / name
FILES.update({"reviewer-tools/" + name: HERE / name for name in ("verify.py", "native_recovery.py", "package_evidence.py")})
manifest = {"source_commit": "64582a3007fea0fa3d1b1c3c212168b96af6b607",
            "performed_by": "Codex agent-assisted on C machine; not C personal attestation",
            "platform": "macOS26.6.2 arm64; native PostgreSQL16.2, no Docker/Compose verification",
            "files": []}
for name, path in FILES.items():
    content = path.read_bytes()
    if name.endswith(".log"):
        text = content.decode("utf-8")
        assert not re.search(r"postgresql(?:\+psycopg)?://[^\s/@:]+:[^\s/@]+@", text), name
        assert not re.search(r"(?:gh[pousr]_[A-Za-z0-9]{15,}|Bearer [A-Za-z0-9._-]{15,})", text), name
    manifest["files"].append({"path": name, "sha256": hashlib.sha256(content).hexdigest()})
OUTPUT = HERE.parent / "member-c-f02-evidence-20260912.zip"
with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED) as archive:
    for name, path in FILES.items():
        archive.write(path, name)
    archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
with zipfile.ZipFile(OUTPUT) as archive:
    assert archive.testzip() is None
print(json.dumps(manifest, ensure_ascii=False, indent=2))
print("Archive:", OUTPUT)
print("Archive SHA-256:", hashlib.sha256(OUTPUT.read_bytes()).hexdigest())
