"""C agent-assisted evidence runner; no project source modifications."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import platform
import subprocess
import sys
import zipfile
from datetime import datetime
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
ROOT = HERE / "returnops-au-fix-10-kan-32-contract-review"
BASE = HERE.parent.parent / "ReturnOps_main_2026-09-07_9eb7b0b/returnops-au-main"
PY = HERE.parent / "returnops-au-fix-10-kan-32-contract-review/.venv-c-review/bin/python"
NODE_BIN = HERE / "node-v24.19.0-darwin-arm64/bin"
LOGS = HERE / "logs"
LOGS.mkdir(exist_ok=True)
ENV = os.environ.copy()
ENV.update(PATH=str(NODE_BIN) + os.pathsep + ENV.get("PATH", ""),
           PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", NO_COLOR="1",
           PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", PYTEST_ADDOPTS="-p no:cacheprovider")

def run(name, args, expected=0):
    stamp = datetime.now(ZoneInfo("Australia/Sydney")).isoformat()
    result = subprocess.run([str(x) for x in args], cwd=ROOT, env=ENV,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, errors="replace")
    content = f"Time: {stamp}\nCommand: {args!r}\n" + result.stdout + f"\nExit: {result.returncode}\n"
    (LOGS / f"{name}.log").write_text(content, encoding="utf-8")
    print(content, flush=True)
    if result.returncode != expected:
        raise SystemExit(f"{name}: expected {expected}, got {result.returncode}")

def verify_source():
    archive = HERE.parent / "rc5-source.zip"
    with zipfile.ZipFile(archive) as z:
        assert z.comment.decode() == "64582a3007fea0fa3d1b1c3c212168b96af6b607", z.comment
        assert z.testzip() is None
    manifest = json.loads((ROOT / "docs/reviews/rc5-publication-artifacts-20260907.json").read_text())
    results = []
    for item in manifest["files"]:
        content = (ROOT / item["path"]).read_bytes()
        digest = hashlib.sha256(content).hexdigest()
        assert digest == item["sha256"], item["path"]
        results.append(f"PASS {item['path']} {digest}")
    spec = importlib.util.spec_from_file_location("model_check", ROOT / "tools/model-checks/check.py")
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    current = checker.allocation_rows(checker.read(ROOT / checker.WBS_PATH))
    baseline = checker.allocation_rows(checker.read(BASE / checker.WBS_PATH))
    assert baseline == current
    checker.validate_wbs(current)
    results += [f"Publication manifest: {len(results)}/{len(manifest['files'])} raw archive bytes match normalized Git-blob hashes.",
                f"Direct snapshot WBS comparison: {len(current)} ID/Owner/Reviewer/S/F rows equal actual main snapshot; not a Git-ref comparison.",
                f"Archive SHA-256: {hashlib.sha256(archive.read_bytes()).hexdigest()}",
                f"Archive Git comment: {z.comment.decode()}",
                "This is source-archive provenance, not a clean Git checkout or git rev-parse attestation."]
    output = "\n".join(results) + "\n"
    (LOGS / "source-integrity.log").write_text(output, encoding="utf-8")
    print(output)

if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "integrity":
        verify_source()
    elif mode == "install":
        run("python-version", [PY, "-c", "import sys,platform;print(sys.version);print(platform.platform())"])
        run("locked-install", [PY, "-m", "pip", "install", "--require-hashes", "-r", "requirements-dev.lock"])
        run("editable-install", [PY, "-m", "pip", "install", "--no-deps", "--no-build-isolation", "-e", "."])
        run("pip-check", [PY, "-m", "pip", "check"])
        run("node-version", [NODE_BIN / "node", "--version"])
        run("npm-version", [NODE_BIN / "npm", "--version"])
        run("npm-ci", [NODE_BIN / "npm", "ci", "--prefix", "tools/model-checks", "--ignore-scripts", "--no-audit", "--no-fund"])
    elif mode == "tests":
        run("offline", [PY, "-B", "tools/checks/run.py", "offline", "--skip-baseline"])
        run("environment-non-db", [PY, "-B", "-m", "pytest", "tests/environment", "-m", "not database", "-q"])
        run("missing-config", [PY, "-B", "tools/checks/run.py", "environment"], expected=2)
    elif mode == "native":
        run("postgres-version", ["/Library/PostgreSQL/16/bin/postgres", "--version"])
        run("native-environment", [PY, "-B", "tools/environment/native_check.py", "--bin", "/Library/PostgreSQL/16/bin", "--db-port", "15433", "--api-port", "18001"])
